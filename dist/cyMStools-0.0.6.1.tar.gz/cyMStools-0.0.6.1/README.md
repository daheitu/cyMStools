# release note May, 30， 2020
## add readmgf function, 
## add calculation the similarity of two spectra


# cyMStools
mass spec tools
summary the plink2 reports file
# Useage 
1. from cyMStools import *
2. summary_plink2_report(reports_path, spectra_cutoff, e-value_cutoff)
